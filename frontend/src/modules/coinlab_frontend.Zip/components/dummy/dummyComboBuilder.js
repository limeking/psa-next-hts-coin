export const dummyComboBuilder = [
    { comboId: 1, connector: 'AND' }, // 상승률 3% 이상
    { comboId: 2, connector: 'AND' }, // 거래대금 10억 이상
    { comboId: 3, connector: 'OR' },  // RSI 30 이상
  ];
  