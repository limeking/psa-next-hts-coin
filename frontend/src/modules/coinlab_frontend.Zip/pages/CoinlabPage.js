// modules/coinlab/pages/CoinlabPage.js
import CoinList from '../components/CoinList';
export default function CoinlabPage() {
  return (
    <div>
      <h1>CoinLab</h1>
      <CoinList />
    </div>
  );
}
